Live TV Hub Android Project

Open this folder in Android Studio, wait for Gradle sync, then build the APK:
Build > Generate Signed Bundle / APK > APK

Website URL:
https://livetvhub.rf.gd/

APK download link used inside website:
https://github.com/MdImranTm/livetvhub/releases/download/v1.0.0/LiveTVHub.apk

Playback updates included:
- Smoother HLS buffer profile
- HD/source priority sorting where public sources provide quality metadata
- Better reconnect/recover handling for public streams
- Android hardware acceleration and PiP support

Note: Public IPTV stream quality depends on the source provider. If a source is SD-only, the app cannot turn it into true HD.
